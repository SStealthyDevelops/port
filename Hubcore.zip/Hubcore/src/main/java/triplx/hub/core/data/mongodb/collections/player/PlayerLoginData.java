package triplx.hub.core.data.mongodb.collections.player;

import com.mongodb.client.MongoCollection;
import lombok.Getter;
import lombok.Setter;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.libs.jline.internal.Nullable;
import org.bukkit.entity.Player;
import triplx.core.api.chat.Color;
import triplx.hub.core.data.mongodb.MongoManager;
import triplx.hub.core.utils.Encryptor;

import java.util.UUID;

@SuppressWarnings("all")
public class PlayerLoginData {

    @Getter
    @Setter
    private static PlayerLoginData instance;

    private final MongoCollection collection = MongoManager.getDatabase().getCollection("player-logins");


    private boolean playerExits(UUID uuid) {
        Document doc = new Document("uuid", uuid.toString());

        // collection = null -> means they do not exist
        // collection != null -> means they exist
        return collection.find(doc).first() != null;
    }

    public void createPlayer(Player player) {
        UUID uuid = player.getUniqueId();
//        System.out.println(playerExits(uuid));

        if (!playerExits(uuid)) {
            //do
            Document doc = new Document("uuid", uuid.toString());
            doc.append("email", "").append("password", "").append("last-leave", "").append("last-ip", player.getAddress().toString());


            collection.insertOne(doc);
//            System.out.println("PLAYER EXIST");
        } else {
//            System.out.println("PLAYER NOT EXIST");
        }
    }

    public boolean confirmPassword(UUID uuid, final String password) {
        final String encryptedPass = Encryptor.encrypt(uuid, password);
        System.out.println(encryptedPass);

        Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();

        if (encryptedPass.equals(doc.getString("password"))) {
            return true;
        }

        return false;
    }

    public boolean setPassword(final UUID uuid, final String password, String currentPassword) {
        if (currentPassword == null) {
            currentPassword = "";
        }
        Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();
//        System.out.println(doc.toJson());
        if (!doc.getString("password").equals("") && currentPassword.equalsIgnoreCase("")) { // if you dont have a password and no current password provided
            if (!doc.getString("password").equals(Encryptor.encrypt(uuid, currentPassword))) {
                return false;
            }
        }

        String encryptedPass = Encryptor.encrypt(uuid, password);

        update(uuid, "password", encryptedPass);
        return true;
    }

    private void update(UUID uuid, String key, String newVal) {
        Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();

        if (doc != null) {
            Bson updatedValue = new Document(key, newVal);
            Bson updateOp = new Document("$set", updatedValue);

            collection.updateOne(doc, updateOp);
        }

    }

    public boolean setEmail(UUID uuid, String email) {
        Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();

        if (!doc.getString("email").equals("")) {
            return false;
        }

        update(uuid, "email", email);
        return true;
    }

    public long getLastQuit(UUID uuid) {
        try {
            Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();

            return Long.parseLong(doc.getString("last-leave"));
        }catch (Exception e) {
            return 0L;
        }
    }

    public boolean hasLogin(UUID uuid) {
        try {
            Document doc = (Document) collection.find(new Document("uuid", uuid.toString())).first();


            String pass = doc.getString("password");

            return (!pass.equals(""));
        } catch (NullPointerException e) {
            Bukkit.getConsoleSender().sendMessage(Color.cc("&cError reading password from MongoDB database."));
            return false;
        }
    }

    public void updateLastLeave(UUID uuid) {
        final long now = System.currentTimeMillis();
        update(uuid, "last-leave", now + "");
    }

//    public void updateLastIP(Player player) {
//        update(player.getUniqueId(), "last-ip", player.getAddress().toString());
//    }
//
//    public String getLastIP(UUID uuid) {
//        Document doc = (Document) collection.find(new Document("uuid", uuid.toString()));
//        return doc.getString("last-ip");
//    }
// DOESNT WORK WITH BUNGEE * TODO
}
