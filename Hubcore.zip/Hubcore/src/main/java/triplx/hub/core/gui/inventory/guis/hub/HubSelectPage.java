package triplx.hub.core.gui.inventory.guis.hub;

public class HubSelectPage {
}
