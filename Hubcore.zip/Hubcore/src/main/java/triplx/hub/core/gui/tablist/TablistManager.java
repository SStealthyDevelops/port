package triplx.hub.core.gui.tablist;


import lombok.Getter;
import lombok.Setter;


public class TablistManager {

    @Getter
    @Setter
    private static TablistManager instance;

    public void init() {

        

    }


}
