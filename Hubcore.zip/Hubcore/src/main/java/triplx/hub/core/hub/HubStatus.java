package triplx.hub.core.hub;

public enum HubStatus {

    OPEN, FULL, MAINTANENCE, CLOSED

}
