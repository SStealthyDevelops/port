package triplx.hub.core.utils;

import org.bukkit.Bukkit;
import triplx.core.api.chat.Color;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtil {

    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public static boolean isEmail(String in) {
        try {
            Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(in);
            return matcher.find();
        } catch (Exception e) {
            Bukkit.getConsoleSender().sendMessage(Color.cc("&cError verifying email " + in ));
            return false;
        }
    }

    public static boolean validPassword(String in) {
        try {
            // Regex to check valid password.
            String regex = "^(?=.*[0-9])"
                    + "(?=.*[a-z])(?=.*[A-Z])"
                    + "(?=.*[@#$%^&+=])"
                    + "(?=\\S+$).{8,20}$";

            // Compile the ReGex
            Pattern p = Pattern.compile(regex);

            // If the password is empty
            // return false
            if (in == null) {
                return false;
            }

            // Pattern class contains matcher() method
            // to find matching between given password
            // and regular expression.
            Matcher m = p.matcher(in);

            // Return if the password
            // matched the ReGex
            return m.matches();
        }catch (Exception e) {
            Bukkit.getConsoleSender().sendMessage(Color.cc("&cError validating password."));
            return false;
        }
    }

}
